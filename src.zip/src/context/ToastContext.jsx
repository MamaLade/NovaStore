import { createContext, useContext, useState } from "react";

const ToastContext = createContext();

export function ToastProvider({ children }) {
  const [toast, setToast] = useState("");

  const showToast = (msg) => {
    setToast(msg);

    setTimeout(() => {
      setToast("");
    }, 1500);
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}

      {toast && (
        <div style={styles.toast}>
          {toast}
        </div>
      )}
    </ToastContext.Provider>
  );
}

const styles = {
  toast: {
    position: "fixed",
    bottom: "20px",
    left: "50%",
    transform: "translateX(-50%)",
    background: "#222",
    color: "#fff",
    padding: "10px 15px",
    borderRadius: "8px",
    zIndex: 99999,
    fontSize: "14px",
  },
};

export const useToast = () => useContext(ToastContext);