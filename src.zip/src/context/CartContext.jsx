import { createContext, useContext, useEffect, useMemo, useReducer, useState } from "react";

const CartContext = createContext();

const initialState = {
  cart: []
};

function cartReducer(state, action) {
  switch (action.type) {

    case "ADD": {
      const item = action.payload;
      const exist = state.cart.find(i => i.id === item.id);

      return {
        cart: exist
          ? state.cart.map(i =>
              i.id === item.id
                ? { ...i, quantity: i.quantity + 1 }
                : i
            )
          : [...state.cart, { ...item, quantity: 1 }]
      };
    }

    case "INC":
      return {
        cart: state.cart.map(i =>
          i.id === action.payload
            ? { ...i, quantity: i.quantity + 1 }
            : i
        )
      };

    case "DEC":
      return {
        cart: state.cart
          .map(i =>
            i.id === action.payload
              ? { ...i, quantity: i.quantity - 1 }
              : i
          )
          .filter(i => i.quantity > 0)
      };

    case "REMOVE":
      return {
        cart: state.cart.filter(i => i.id !== action.payload)
      };

    case "CLEAR":
      return {
        cart: []
      };

    case "LOAD":
      return {
        cart: action.payload
      };

    default:
      return state;
  }
}

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(cartReducer, initialState);
  const [orders, setOrders] = useState([]);

  // ===== LOAD CART + ORDERS =====
  useEffect(() => {
    const cartData = localStorage.getItem("novastore_cart");
    const orderData = localStorage.getItem("novastore_orders");

    if (cartData) {
      dispatch({ type: "LOAD", payload: JSON.parse(cartData) });
    }

    if (orderData) {
      setOrders(JSON.parse(orderData));
    }
  }, []);

  // ===== SAVE CART =====
  useEffect(() => {
    localStorage.setItem("novastore_cart", JSON.stringify(state.cart));
  }, [state.cart]);

  // ===== SAVE ORDERS =====
  useEffect(() => {
    localStorage.setItem("novastore_orders", JSON.stringify(orders));
  }, [orders]);

  // ===== TOTALS =====
  const totalPrice = useMemo(
    () => state.cart.reduce((sum, i) => sum + i.price * i.quantity, 0),
    [state.cart]
  );

  const totalQuantity = useMemo(
    () => state.cart.reduce((sum, i) => sum + i.quantity, 0),
    [state.cart]
  );

  // ===== ACTIONS =====
  const addToCart = (item) => dispatch({ type: "ADD", payload: item });
  const increase = (id) => dispatch({ type: "INC", payload: id });
  const decrease = (id) => dispatch({ type: "DEC", payload: id });
  const removeItem = (id) => dispatch({ type: "REMOVE", payload: id });
  const clearCart = () => dispatch({ type: "CLEAR" });

  return (
    <CartContext.Provider
      value={{
        cart: state.cart,
        addToCart,
        increase,
        decrease,
        removeItem,
        clearCart,
        totalPrice,
        totalQuantity,
        orders,
        setOrders
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);