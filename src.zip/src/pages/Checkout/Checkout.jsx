import "./Checkout.css";
import { useCart } from "../../context/CartContext";
import { useNavigate } from "react-router-dom";

function Checkout() {
  const {
    cart,
    totalPrice,
    clearCart,
    orders,
    setOrders
  } = useCart();

  const navigate = useNavigate();

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert("Giỏ hàng trống!");
      return;
    }

    const newOrder = {
      id: Date.now(),
      items: cart,
      total: totalPrice + 20000,
      createdAt: new Date().toISOString()
    };

    setOrders([newOrder, ...orders]);

    clearCart();

    alert("Thanh toán thành công!");
    navigate("/");
  };

  return (
    <div className="checkout">
      <div className="container">

        <h2>Thanh toán</h2>

        <div className="checkout-content">

          <div className="left">
            {cart.map(item => (
              <div key={item.id}>
                {item.name} x{item.quantity}
              </div>
            ))}
          </div>

          <div className="right">
            <p>Tổng: {totalPrice.toLocaleString()}đ</p>
            <p>Ship: 20.000đ</p>

            <h3>
              Tổng thanh toán: {(totalPrice + 20000).toLocaleString()}đ
            </h3>

            <button onClick={handleCheckout}>
              Đặt hàng
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}

export default Checkout;