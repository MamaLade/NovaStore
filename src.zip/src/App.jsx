import { useState } from "react";
import { Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar/Navbar";
import Hero from "./components/Hero/Hero";
import ProductGrid from "./components/ProductGrid/ProductGrid";
import Cart from "./components/Cart/Cart";
import MiniCart from "./components/Cart/MiniCart";
import Checkout from "./pages/Checkout/Checkout";

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMiniOpen, setIsMiniOpen] = useState(false);

  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");

  const [sort, setSort] = useState("default");
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(999999999);

  return (
    <>
      <Navbar
        openCart={() => setIsCartOpen(true)}
        setMiniOpen={setIsMiniOpen}
        search={search}
        setSearch={setSearch}
      />

      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
      />

      <MiniCart
        isOpen={isMiniOpen}
        onClose={() => setIsMiniOpen(false)}
      />

      <Routes>
        <Route
          path="/"
          element={
            <>
              <Hero />
              <ProductGrid
                category={category}
                setCategory={setCategory}
                search={search}
                sort={sort}
                setSort={setSort}
                minPrice={minPrice}
                maxPrice={maxPrice}
              />
            </>
          }
        />

        <Route path="/checkout" element={<Checkout />} />
      </Routes>
    </>
  );
}

export default App;