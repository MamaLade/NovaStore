import "./Navbar.css";
import { FaShoppingCart, FaUser, FaSearch } from "react-icons/fa";
import { useCart } from "../../context/CartContext";
import { useRef } from "react";

function Navbar({ openCart, search, setSearch, setMiniOpen }) {
  const { totalQuantity } = useCart();

  const timer = useRef(null);

  const handleEnter = () => {
    clearTimeout(timer.current);
    setMiniOpen(true);
  };

  const handleLeave = () => {
    timer.current = setTimeout(() => {
      setMiniOpen(false);
    }, 150);
  };

  return (
    <header className="navbar">
      <div className="container nav-content">

        <h2 className="logo">NovaStore</h2>

        <div className="search-box">
          <input
            type="text"
            placeholder="Tìm sản phẩm..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button>
            <FaSearch />
          </button>
        </div>

        <div className="actions">

          <FaUser className="icon" />

          <div
            className="cart"
            onClick={openCart}
            onMouseEnter={handleEnter}
            onMouseLeave={handleLeave}
          >
            <FaShoppingCart className="icon" />
            <span>{totalQuantity}</span>
          </div>

        </div>

      </div>
    </header>
  );
}

export default Navbar;