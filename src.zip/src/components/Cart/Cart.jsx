import "./Cart.css";
import { useCart } from "../../context/CartContext";

function Cart({ isOpen, onClose }) {
  const {
    cart,
    increase,
    decrease,
    removeItem,
    totalPrice
  } = useCart();

  if (!isOpen) return null;

  return (
    <div className="cart-overlay">
      <div className="cart-box">

        <div className="cart-header">
          <h2>Giỏ hàng</h2>
          <button onClick={onClose}>✕</button>
        </div>

        {cart.length === 0 ? (
          <p className="empty">Giỏ hàng trống</p>
        ) : (
          cart.map(item => (
            <div className="cart-item" key={item.id}>

              <div className="info">
                <h4>{item.name}</h4>
                <p>{item.price.toLocaleString()}đ</p>
              </div>

              <div className="qty">
                <button onClick={() => decrease(item.id)}>-</button>
                <span>{item.quantity}</span>
                <button onClick={() => increase(item.id)}>+</button>
              </div>

              <button
                className="remove"
                onClick={() => removeItem(item.id)}
              >
                X
              </button>

            </div>
          ))
        )}

        <div className="cart-footer">
          <h3>Tổng tiền: {totalPrice.toLocaleString()}đ</h3>
        </div>

      </div>
    </div>
  );
}

export default Cart;