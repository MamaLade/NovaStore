import "./Cart.css";
import { useCart } from "../../context/CartContext";

function MiniCart({ isOpen, onClose }) {
  const { cart, totalPrice } = useCart();

  if (!isOpen) return null;

  return (
    <div className="mini-cart-overlay" onClick={onClose}>
      <div className="mini-cart" onClick={(e) => e.stopPropagation()}>

        <h3>Giỏ hàng nhanh</h3>

        {cart.length === 0 ? (
          <p>Giỏ hàng trống</p>
        ) : (
          cart.slice(0, 3).map(item => (
            <div key={item.id} className="mini-item">
              <span>{item.name}</span>
              <b>x{item.quantity}</b>
            </div>
          ))
        )}

        <div className="mini-footer">
          Tổng: {totalPrice.toLocaleString()}đ
        </div>

      </div>
    </div>
  );
}

export default MiniCart;