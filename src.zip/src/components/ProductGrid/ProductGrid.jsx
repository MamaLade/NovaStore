import "./ProductGrid.css";
import ProductCard from "../ProductCard/ProductCard";
import products from "../../data/products";
import { useCart } from "../../context/CartContext";

function ProductGrid({
  category,
  setCategory,
  search,
  sort,
  setSort,
  minPrice = 0,
  maxPrice = Infinity,
}) {
  const { addToCart } = useCart();

  let filteredProducts = products
    .filter((p) => category === "all" || p.category === category)
    .filter((p) =>
      p.name.toLowerCase().includes(search.toLowerCase())
    )
    .filter((p) => p.price >= minPrice && p.price <= maxPrice)
    .slice();

  // SORT
  if (sort === "price_asc") {
    filteredProducts.sort((a, b) => a.price - b.price);
  }

  if (sort === "price_desc") {
    filteredProducts.sort((a, b) => b.price - a.price);
  }

  if (sort === "rating") {
    filteredProducts.sort((a, b) => b.rating - a.rating);
  }

  if (sort === "sold") {
    filteredProducts.sort((a, b) => b.sold - a.sold);
  }

  const handleAddToCart = (product) => {
    addToCart(product);
  };

  return (
    <section className="product-section">
      <div className="container">

        {/* CATEGORY + SORT */}
        <div className="top-bar">

          <div className="category-bar">
            <button
              className={category === "all" ? "active" : ""}
              onClick={() => setCategory("all")}
            >
              🔥 Tất cả
            </button>

            <button onClick={() => setCategory("ao")}>👕 Áo</button>
            <button onClick={() => setCategory("quan")}>👖 Quần</button>
            <button onClick={() => setCategory("giay")}>👟 Giày</button>
          </div>

          <select
            className="sort"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="default">Mặc định</option>
            <option value="price_asc">Giá thấp → cao</option>
            <option value="price_desc">Giá cao → thấp</option>
            <option value="sold">Bán chạy</option>
            <option value="rating">Đánh giá cao</option>
          </select>

        </div>

        <h2 className="title">🔥 Sản phẩm nổi bật</h2>

        <div className="grid">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={() => handleAddToCart(product)}
              />
            ))
          ) : (
            <div className="empty">
              Không tìm thấy sản phẩm
            </div>
          )}
        </div>

      </div>
    </section>
  );
}

export default ProductGrid;