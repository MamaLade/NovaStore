import "./Hero.css";

function Hero() {
  return (
    <section className="hero">
      <div className="container hero-content">

        <h1>🔥 Siêu Sale 50%</h1>
        <p>Hàng ngàn sản phẩm giảm giá hôm nay</p>

        <button>Mua ngay</button>

      </div>
    </section>
  );
}

export default Hero;