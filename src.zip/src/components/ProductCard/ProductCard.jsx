import "./ProductCard.css";
import { FaStar, FaHeart, FaShoppingCart } from "react-icons/fa";

function ProductCard({ product, onAddToCart }) {
  const discount = product.oldPrice
    ? Math.floor(
        ((product.oldPrice - product.price) /
          product.oldPrice) *
          100
      )
    : 0;

  return (
    <div className="card">

      {/* IMAGE */}
      <div className="image-box">
        <img src={product.image} alt={product.name} />

        <span className="discount">-{discount}%</span>

        <FaHeart className="heart" />
      </div>

      {/* INFO */}
      <div className="info">
        <h3 className="name">{product.name}</h3>

        {/* rating + sold */}
        <div className="meta">
          <div className="rating">
            <FaStar className="star" />
            <span>{product.rating}</span>
          </div>

          <span className="sold">
            Đã bán {product.sold}
          </span>
        </div>

        {/* PRICE */}
        <div className="price-box">
          <span className="price">
            {product.price.toLocaleString()}₫
          </span>

          <span className="old-price">
            {product.oldPrice?.toLocaleString?.() || ""}
          </span>
        </div>

        {/* BUTTON */}
        <button
          className="btn"
          onClick={onAddToCart}
        >
          <FaShoppingCart />
          <span>Thêm vào giỏ</span>
        </button>

      </div>

    </div>
  );
}

export default ProductCard;